# AFGNN
Pytorch Implementation of paper: 
Demystifying Graph Neural Network Via Graph Filter Assessment
