import numpy as np
import random
import sys
from sklearn import datasets
import pickle as pkl
import scipy.sparse as sp
import torch
import networkx as nx

def high_dim_gaussian(mu, sigma):
    '''
    generate d dim vector
    each dim obeys a gaussian distribution
    input:
    mu: numpy vector
    sigma: numpy vector
    '''
    if mu.ndim > 1:
        d = len(mu)
        res = np.zeros(d)
        for i in range(d):
            res[i] = np.random.normal(mu[i], sigma[i])
    else:
        d = 1
        res = np.zeros(d)
        res = np.random.normal(mu, sigma)
    return res

def make_rings(sizes, radius, noise, Y):
    '''
    generate ring features
    input:
    sizes: c dim numpy vector
    radius: c dim numpy vector
    noise: scaler
    output:
    X: feature matrix of dim n*2 (n = num of nodes)
    '''
    n = sizes.sum()
    c = len(sizes)
    all_node_ids = [ids for ids in range(0,n)]  
    linespace = []
    circ_x = []
    circ_y = []
    for i in range(c):
        linespace.append(np.linspace(0, 2 * np.pi, sizes[i], endpoint=False))
        circ_x.append(np.cos(linespace[i]) * radius[i])
        circ_y.append(np.sin(linespace[i]) * radius[i])
    X = []
    idx = np.zeros(c, dtype = 'int')
    for i in range(n):
        if noise is not None:
            X.append([circ_x[Y[i]][idx[Y[i]]] + random.gauss(0, noise * radius[Y[i]]), \
                circ_y[Y[i]][idx[Y[i]]] + random.gauss(0, noise * radius[Y[i]])])
        else:
            X.append([circ_x[Y[i]][idx[Y[i]]], circ_y[Y[i]][idx[Y[i]]]])
        idx[Y[i]] = idx[Y[i]] + 1
    X = np.array(X)
    return X

def generate_uniform_theta(Y, c):
    '''
    for DCSBM, generate theta follows uniform distribution
    constraint: each class, sum theta =1
    '''
    theta = np.zeros(len(Y),dtype = 'float')
    for i in range(c):
        idx = np.where(Y == i)
        sample = np.random.uniform(low=0, high=1, size=len(idx[0]) )
        sample_sum = np.sum(sample)
        for j in range(len(idx[0])):
            theta[idx[0][j]] = sample[j] * len(idx[0])/sample_sum
    return theta


def generate_theta_dirichlet(Y, c):
    '''
    for DCSBM, generate theta follows dirichlet distribution
    constraint: each class, sum theta =1
    '''
    theta = np.zeros(len(Y),dtype = 'float')
    for i in range(c):
        idx = np.where(Y == i)
        temp = np.random.uniform(low=0, high=1, size=len(idx[0]) )
        sample = np.random.dirichlet(temp, 1)
        sample_sum = np.sum(sample)
        for j in range(len(idx[0])):
            theta[idx[0][j]] = sample[0][j] * len(idx[0])/sample_sum
    return theta

def normalize_row(mx):#orginal
    """Row-normalize sparse matrix"""
#     mx here corresponds to adj matrix
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.#turn inf into 0
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx


def parse_index_file(filename):
    """Parse index file."""
    index = []
    for line in open(filename):
        index.append(int(line.strip()))
    return index

#--------------------------------------
'''
Synthetic Data Generation
- 3 typs:
  1)SBM with gaussian feature
  2)SBM with circle feature
  3)DCSBM with gaussian feature
 - output: 
  1)A: numpy matrix, adjacency
  2)X: numpy matrix, features
  3)Y: numpy vector, labels
'''
#--------------------------------------

def SBM(sizes, probs, mus, sigmas, noise, \
	radius, feats_type='gaussian', selfloops=True): 
    '''
    not directed
    -------------------------
    input: 
    sizes: numpy vector,  dim c (c = number of class)
    probs: numpy matrix, dim c*c
    mus: numpy matrix, dim c * d (d = number of feature dimension)
    	 for gaussian feats
    sigmas: numpy matrix of dim c * d, for gaussian feats
    noise: scaler
    radius: numpy vector of dim c
    feats_type: "gaussian" or "rings"
    selfloops: bool, add self-loop to A or not
    -------------------------
    output:
    A: numpy matrix, adjacency 
    X: numpy matrix, features
    Y: numpy vector, labels
    '''
# -----------------------------------------------  
#     step1: get c,d,n
# -----------------------------------------------  
    c = len(sizes)
    if mus.ndim>1:
        d = mus.shape[1]
    else:
        d = 1
    n = sizes.sum()
    all_node_ids = [ids for ids in range(0,n)] 
# -----------------------------------------------      
#     step2: generate Y with sizes
# -----------------------------------------------  
    Y = np.zeros(n, dtype = 'int')
    for i in range(c):
        class_i_ids = random.sample(all_node_ids, sizes[i])
        Y[class_i_ids] = i
        for item in class_i_ids:
            all_node_ids.remove(item)
# -----------------------------------------------      
#     step3: generate A with Y and probs
# -----------------------------------------------  
    if selfloops:
        A = np.diag(np.ones(n, dtype = 'int'))
    else:
        A = np.zeros((n,n), dtype = 'int')
    for i in range(n):
        for j in range(i + 1, n):
            prob_ = probs[Y[i]][Y[j]]
            rand_ = random.random()
            if rand_<=prob_:
                A[i][j] = 1
                A[j][i] = 1
# -----------------------------------------------  
#     step4: generate X with Y and mus, sigmas
# ----------------------------------------------- 
    if feats_type == 'rings':
        if d != 2:
            print("Can not generate rings, feature dimension does not fit")
            sys.exit(1)
        else:
            X = make_rings(sizes, radius, noise, Y)
    else:
        X = np.zeros((n ,d), dtype = 'float')
        for i in range(n):
            mu = mus[Y[i]]
            sigma = sigmas[Y[i]]
            X[i] = high_dim_gaussian(mu, sigma)   

    return A, X, Y


def DCSBM(sizes, probs, mus, sigmas, dist_theta = 'dirichlet', selfloops=True): 
    '''
    not directed, degree corrected SBM
    -------------------------
    input: 
    sizes: numpy vector,  dim c (c = number of class)
    probs: numpy matrix, dim c*c
    mus: numpy matrix, dim c * d (d = number of feature dimension)
    sigmas: numpy matrix of dim c * d
    dist_theta: 'dirichlet' or 'uniform', choose dirichlet to get power law degree distribution
    selfloops: bool, add self-loop to A or not
    -------------------------
    output:
    A: numpy matrix, adjacency 
    X: numpy matrix, features
    Y: numpy vector, labels
    '''
# -----------------------------------------------  
#     step1: get c,d,n
# -----------------------------------------------  

    c = len(sizes)
    if mus.ndim>1:
        d = mus.shape[1]
    else:
        d = 1
    n = sizes.sum()
    all_node_ids = [ids for ids in range(0,n)]
    
# -----------------------------------------------      
#     step2: generate Y with sizes
# -----------------------------------------------  
    Y = np.zeros(n, dtype = 'int')
    for i in range(c):
        class_i_ids = random.sample(all_node_ids, sizes[i])
        Y[class_i_ids] = i
        for item in class_i_ids:
            all_node_ids.remove(item)
            
# -----------------------------------------------      
#     step3: generate degree corrction vector
# ----------------------------------------------- 
    if dist_theta == 'dirichlet':
        theta = generate_theta_dirichlet(Y, c)
    else:
        theta = generate_uniform_theta(Y, c)

# -----------------------------------------------      
#     step4: generate A with Y and probs
# -----------------------------------------------  
    if selfloops:
        A = np.diag(np.ones(n, dtype = 'int'))
    else:
        A = np.zeros((n,n), dtype = 'int')
    for i in range(n):
        for j in range(i + 1, n):
            prob_ = probs[Y[i]][Y[j]]*theta[i]*theta[j]
            rand_ = random.random()
            if rand_<=prob_:
                A[i][j] = 1
                A[j][i] = 1

# -----------------------------------------------  
#     step5: generate X with Y and mus, sigmas
# ----------------------------------------------- 
    X = np.zeros((n ,d), dtype = 'float')
    for i in range(n):
        mu = mus[Y[i]]
        sigma = sigmas[Y[i]]
        X[i] = high_dim_gaussian(mu, sigma)

    return A, X, Y   



def BASBM(sizes, probs, mus, sigmas, noise, \
	radius, feats_type='gaussian', selfloops=True): 
    '''
    not directed
    -------------------------
    input: 
    sizes: numpy vector,  dim c (c = number of class)
    probs: numpy matrix, dim c*c
    mus: numpy matrix, dim c * d (d = number of feature dimension)
    	 for gaussian feats
    sigmas: numpy matrix of dim c * d, for gaussian feats
    noise: scaler
    radius: numpy vector of dim c
    feats_type: "gaussian" or "rings"
    selfloops: bool, add self-loop to A or not
    -------------------------
    output:
    A: numpy matrix, adjacency 
    X: numpy matrix, features
    Y: numpy vector, labels
    '''
# -----------------------------------------------  
#     step1: get c,d,n
# -----------------------------------------------  
    c = len(sizes)
    if mus.ndim>1:
        d = mus.shape[1]
    else:
        d = 1
    n = sizes.sum()
    all_node_ids = [ids for ids in range(0,n)] 
    temp = n/4 #control probability
# -----------------------------------------------      
#     step2: generate Y with sizes
# -----------------------------------------------  
    Y = np.zeros(n, dtype = 'int')
    for i in range(c):
        class_i_ids = random.sample(all_node_ids, sizes[i])
        Y[class_i_ids] = i
        for item in class_i_ids:
            all_node_ids.remove(item)
# -----------------------------------------------      
#     step3: generate A with Y and probs
# -----------------------------------------------  
    if selfloops:
        A = np.diag(np.ones(n, dtype = 'int'))
        degree = np.ones(n)
    else:
        A = np.zeros((n,n), dtype = 'int')
        degree = np.ones(n)
    for i in range(n):
        for j in range(i + 1, n):
            prob_ = probs[Y[i]][Y[j]] * temp * degree[i]/np.sum(degree)
            rand_ = random.random()
            if rand_<=prob_:
                A[i][j] = 1
                A[j][i] = 1
                degree[i] = degree[i] + 1
                degree[j] = degree[j] + 1
# -----------------------------------------------  
#     step4: generate X with Y and mus, sigmas
# ----------------------------------------------- 
    if feats_type == 'rings':
        if d != 2:
            print("Can not generate rings, feature dimension does not fit")
            sys.exit(1)
        else:
            X = make_rings(sizes, radius, noise, Y)
    else:
        X = np.zeros((n ,d), dtype = 'float')
        for i in range(n):
            mu = mus[Y[i]]
            sigma = sigmas[Y[i]]
            X[i] = high_dim_gaussian(mu, sigma)   

    return A, X, Y


#--------------------------------------
'''
Load Benchmark Dataset and Synthetic Dataset
'''
#--------------------------------------
def load_benchmark(dataset="pubmed"):#citeseer, pubmed, cora
    """
    Load benchmark dataset: citeseer, pubmed, cora
    all outputs are tensors
    REFER: https://github.com/kimiyoung/planetoid
    """
    print('Loading {} dataset...'.format(dataset))

    names = ['x', 'y', 'tx', 'ty', 'allx', 'ally', 'graph']
    objects = []
    for i in range(len(names)):
        with open("data/benchmark/ind.{}.{}".format(dataset, names[i]), 'rb') as f:
            if sys.version_info > (3, 0):
                objects.append(pkl.load(f, encoding='latin1'))
            else:
                objects.append(pkl.load(f))
    
    x, y, tx, ty, allx, ally, graph = tuple(objects)
    test_idx_reorder = parse_index_file("data/benchmark/ind.{}.test.index".format(dataset))
    test_idx_range = np.sort(test_idx_reorder)
    
    if dataset == 'citeseer':
        # Fix citeseer dataset (there are some isolated nodes in the graph)
        # Find isolated nodes, add them as zero-vecs into the right position
        test_idx_range_full = range(min(test_idx_reorder), max(test_idx_reorder)+1)
        tx_extended = sp.lil_matrix((len(test_idx_range_full), x.shape[1]))
        tx_extended[test_idx_range-min(test_idx_range), :] = tx
        tx = tx_extended
        ty_extended = np.zeros((len(test_idx_range_full), y.shape[1]))
        ty_extended[test_idx_range-min(test_idx_range), :] = ty
        ty = ty_extended


# efficient version
    features_ = sp.vstack((allx, tx)).tolil()
    features_[test_idx_reorder, :] = features_[test_idx_range, :]   
    features = sp.csr_matrix(features_).toarray()
    features = normalize_row (features)
    features = torch.FloatTensor(features)
    
   
    adj = nx.adjacency_matrix(nx.from_dict_of_lists(graph))
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    adj = adj + np.eye(features.shape[0])
    adj = torch.FloatTensor(adj)
    
    labels = np.vstack((ally, ty))
    labels[test_idx_reorder, :] = labels[test_idx_range, :]
    
    idx_test = test_idx_range.tolist()
    idx_train = range(len(y))
    idx_train = list(idx_train)
    idx_val = range(len(y), len(y)+500)
    idx_val = list(idx_val)
    
    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)
    
    features = torch.FloatTensor(features)
    
 
    l = np.where(~labels.any(axis=1))[0]
   
    if len(l)>0:
        for i in range(len(l)):
            labels[l[i]][1] = 1
    
    labels = torch.LongTensor(np.where(labels)[1])
    labels = torch.LongTensor(labels)
    print("finish load data")
    return adj, features, labels, idx_train, idx_val, idx_test



def load_synthetic(dataset, split_index):
    '''
    load synthetic datasets
    all outputs are tensors
    the generated data already has selfloop
    '''
    print('Loading {} dataset...'.format(dataset))
    items = ['A_', 'X_', 'Y_']
    objects = []
    for i in items:
        file = open('./data/synthetic/'+i+dataset+'.pkl', 'rb')
        objects.append(pkl.load(file))
        file.close()
    A, X, Y = tuple(objects)

    adj = torch.FloatTensor(A)
    features = torch.FloatTensor(X)
    labels = torch.LongTensor(Y)

    n = features.shape[0]

    
#     random.seed (10)
#     list_n = list(range(int(n)))
#     idx_fold1 = random.sample(list_n, int(n*0.2))
#     for item in idx_fold1:
#         list_n.remove(item)
#     idx_fold2 = random.sample(list_n, int(n*0.2))
#     for item in idx_fold2:
#         list_n.remove(item)
#     idx_fold3 = random.sample(list_n, int(n*0.2))
#     for item in idx_fold3:
#         list_n.remove(item)
#     idx_fold4 = random.sample(list_n, int(n*0.2))
#     for item in idx_fold4:
#         list_n.remove(item)
#     idx_fold5 = random.sample(list_n, int(n*0.2))
    
    idx_fold1 = range(int(n * 0.2))
    idx_fold2 = range(int(n * 0.2),int(n * 0.4))
    idx_fold3 = range(int(n * 0.4),int(n * 0.6))
    idx_fold4 = range(int(n * 0.6),int(n * 0.8))
    idx_fold5 = range(int(n * 0.8),int(n))
    idx_fold = [idx_fold1, idx_fold2, idx_fold3, idx_fold4, idx_fold5]
    
    idx_train = idx_fold[int(split_index % 5)]
    idx_val = idx_fold[int((split_index + 1) % 5)]
    idx_test = idx_fold[int((split_index + 2) % 5)]

    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)

    print("finish load data")
    return adj, features, labels, idx_train, idx_val, idx_test




