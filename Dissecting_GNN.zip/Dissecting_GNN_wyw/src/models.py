import torch.nn as nn
import torch.nn.functional as F
import torch
from src.layers import GraphConvolution, GraphIsomorphism, AccommodativeGraph
import sys

class GCN(nn.Module):
    '''
    two layer GCN
    one normalized adj
    '''
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
#         self.gc3 = GraphConvolution(nhid, nclass)
        self.dropout = dropout

    
    def forward(self, x, adj):# x and adj are the input for this GCN module
        u1, fp1 = self.gc1(x, adj)
        u1 = F.relu(u1)
        u1 = F.dropout(u1, self.dropout, training=self.training)
        u2, fp2 = self.gc2(u1, adj)
#         u2 = F.relu(u2)
#         u2, fp2 = self.gc3(u2,adj)
        res = F.log_softmax(u2, dim = 1)
        return res, fp1, u2
    
    
# class GCN_withnorm(nn.Module):
#     '''
#     two layer GCN
#     one normalized adj
#     '''
#     def __init__(self, nfeat, nhid, nclass, dropout):
#         super(GCN_withnorm, self).__init__()
#         self.gc1 = GraphConvolution(nfeat, nhid)
#         self.gc2 = GraphConvolution(nhid, nclass)
#         self.dropout = dropout

#     def norm(self, feature):
#         assert len(feature.shape) == 2
#         mean = feature.mean(dim = 0,keepdim = True)
#         var = feature.std(dim = 0,keepdim = True)
#         return (feature - mean) / (var + 1e-6)
    
#     def forward(self, x, adj):# x and adj are the input for this GCN module
#         u1, fp1 = self.gc1(x, adj)
#         u1 = F.relu(u1)
#         u1 = self.norm(u1)
#         u1 = F.dropout(u1, self.dropout, training=self.training)
#         u2, fp2 = self.gc2(u1, adj)
#         res = F.log_softmax(u2, dim = 1)
#         return res, fp1, u2


class GIN(nn.Module):
    '''
    two layer GIN
    one raw adj
    '''
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GIN, self).__init__()

        self.gi1 = GraphIsomorphism(nfeat, nhid)
        self.gi2 = GraphIsomorphism(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj):
        u1, fp1 = self.gi1(x, adj)
        h1 = F.relu(u1)
        h1 = F.dropout(h1, self.dropout, training=self.training)
        u2, fp2 = self.gi2(h1, adj)
        res = F.log_softmax(u2, dim = 1)
        return res, fp1, fp2


class GFN(nn.Module):
    '''
    1 mlp layer
    adj is identity matrix
    feature is concate(d, X, FX, ...)
    '''
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GFN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj):
        fp = x
        x, tmp = self.gc1(x, adj)
        x = F.relu(x)
        x = F.dropout(x, self.dropout, training=self.training)
        x, tmp = self.gc2(x,adj)
        res = F.log_softmax(x, dim=1)
        return res, fp, 0


class SGC(nn.Module):
    """
    SGC layer
    x is propagated feature, adj is None
    """
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(SGC, self).__init__()
        self.W1 = nn.Linear(nfeat, nclass)
        #self.W2 = nn.Linear(nhid, nclass)

    def forward(self, x, adj):
        fp = x
        x = self.W1(x)
        #x = self.W2(x)
        res = F.log_softmax(x, dim=1)
        return res, fp, 0


class GFNN(nn.Module):
    """
    gfnn layer
    x is propagated feature
    """
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GFNN, self).__init__()
        self.W1 = nn.Linear(nfeat, nhid)
        self.W2 = nn.Linear(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj):
        fp = x
        x = F.relu(self.W1(x))
        x = self.W2(x)
        res = F.log_softmax(x, dim=1)
        return res, fp, 0


class AGNN_cora(nn.Module):
    '''
    accommodative gnn
    adj is list of normalized adjacency matrix
    '''
    def __init__(self, nfeat, nclass,degree):
        super(AGNN_cora, self).__init__()
        self.gc1 = AccommodativeGraph(nfeat, nclass,degree)
        self.mapping = nn.Parameter(torch.FloatTensor(self.gc1.out_features, nclass))
        self.reset_params()

    def reset_params(self):
        torch.nn.init.xavier_normal_(self.mapping)
        
    def norm(self, feature):
        assert len(feature.shape) == 2
        mean = feature.mean(dim = 0,keepdim = True)
        var = feature.std(dim = 0,keepdim = True)
        return (feature - mean) / (var + 1e-6)
          
    def forward(self, x, adj):# x and adj are the input for this GCN module
        u1, fp1 = self.gc1(x, adj)
        u1 = F.relu(u1)
        u1 = torch.mm(u1, self.mapping)
        res = F.log_softmax(u1, dim=1)
        return res, fp1, 0

    
class AGNN_syn(nn.Module):
    '''
    accommodative gnn
    adj is list of normalized adjacency matrix
    '''
    def __init__(self, nfeat, nclass,degree):
        super(AGNN_syn, self).__init__()
        self.gc1 = AccommodativeGraph(nfeat, nclass,degree)
        self.mapping = nn.Parameter(torch.FloatTensor(self.gc1.out_features, nclass))
        self.reset_params()

    def reset_params(self):
        torch.nn.init.xavier_normal_(self.mapping)
        
    def norm(self, feature):
        assert len(feature.shape) == 2
        mean = feature.mean(dim = 0,keepdim = True)
        var = feature.std(dim = 0,keepdim = True)
        return (feature - mean) / (var + 1e-6)

          
    def forward(self, x, adj):# x and adj are the input for this GCN module
        u1, fp1 = self.gc1(x, adj)
        u1 = F.relu(u1)
        u1 = self.norm(u1)
        u1 = torch.mm(u1, self.mapping)
        res = F.log_softmax(u1, dim=1)
        return res, fp1, 0
    
class PreCompute_AFGNN(nn.Module):
    """
    
    x is propagated feature, adj is None
    """
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(PreCompute_AFGNN, self).__init__()
        self.W1 = nn.Linear(nfeat, nclass)
        #self.W2 = nn.Linear(nhid, nclass)

    def forward(self, x, adj):
        fp = x
        x = self.W1(x)
        #x = self.W2(x)
        res = F.log_softmax(x, dim=1)
        return res, fp, 0


def get_model(model_opt, nfeat, nclass, nhid, dropout, cuda, dataset, degree):
    if model_opt == "GCN":
        model = GCN(nfeat=nfeat,
                    nhid=nhid,
                    nclass=nclass,
                    dropout=dropout)
#         if dataset == "cora" or dataset == "citeseer" or dataset == "pubmed":
#             model = GCN(nfeat=nfeat,
#                         nhid=nhid,
#                         nclass=nclass,
#                         dropout=dropout)
#         else:
#             model = GCN_withnorm(nfeat=nfeat,
#                         nhid=nhid,
#                         nclass=nclass,
#                         dropout=dropout)
    elif model_opt == "SGC":
        model = SGC(nfeat=nfeat,
                    nhid=nhid,
                    nclass=nclass,
                    dropout=dropout)
            
    elif model_opt == "GFNN":
        model = GFNN(nfeat=nfeat,
                        nhid=nhid,
                        nclass=nclass,
                        dropout=dropout)
    elif model_opt == "GFN":
        model = GFN(nfeat=nfeat,
                        nhid=nhid,
                        nclass=nclass,
                        dropout=dropout)
    elif model_opt == "GIN":
        model = GIN(nfeat=nfeat,
                        nhid=nhid,
                        nclass=nclass,
                        dropout=dropout)
    elif model_opt == "PreCompute_AFGNN":
        model = PreCompute_AFGNN(nfeat=nfeat,
                    nhid=nhid,
                    nclass=nclass,
                    dropout=dropout)
    elif model_opt == "AGNN":
        if dataset == "cora" or dataset == "citeseer" or dataset == "pubmed":
            model = AGNN_cora(nfeat = nfeat,
                        nclass=nclass,
                        degree = degree)
        else:
            model = AGNN_syn(nfeat = nfeat,
                        nclass=nclass,
                        degree = degree)
            
    else:
        raise NotImplementedError('model:{} is not implemented!'.format(model_opt))

    #if cuda: model.cuda()
    return model