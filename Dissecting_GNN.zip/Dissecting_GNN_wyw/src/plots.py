import numpy as np
import seaborn as sb
import networkx as nx
import matplotlib.pyplot as plt
import torch

def plot_feature(X, Y, c):
    '''
    input:
    X: numpy matrix, features
    Y: numpy vector, indicators
    c: scaler, number of class
    output:
    feature distribution for X 
    '''
    dim = X.shape[1]
    if dim >2:
        print("Can not plot, dimension is large than 2")
    elif dim == 1:
        for i in range(c):
            sb.distplot(X[Y==i])
        plt.xlabel('feature', fontsize = 13)
        plt.show()
    elif dim == 2:
        sb.scatterplot(X[:, 0], X[:, 1], hue = Y)
        plt.show()
    return 


def plot_heatmap(adj, Y, c):
    '''
    input:
    adj: sparse tensor, normalized adjacency matrix in our case
    Y: numpy vector, indicators
    c: scaler, number of class 
    output:
    heatmap for adj
    '''
    adj = adj.to_dense().numpy()
    idx = []
    for i in range(c):
        idx = idx + np.array(np.where(Y==i))[0].tolist()
    idx = np.array(idx)
    sb.heatmap(adj[idx].T[idx].T)
    plt.show()


def plot_graph(A,Y):
    '''
    input:
    A: numpy matrix, adjacency 
    Y: numpy vector, indicators
    output:
    plot graph structure
    '''
    G = nx.from_numpy_array(A)
    nx.draw(G, node_color = Y, with_labels=False, node_size = 50, width = 0.3)
    return 


def plot_degree(A):
    '''
    input:
    A: numpy matrix, adjacency
    output:
    plot degree distribution
    '''
    degrees = A.sum(axis = 0)
    sb.distplot(degrees)
    return 