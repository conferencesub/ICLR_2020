from src.normalization import normalization
# from plots import plot_feature
import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def norm_expand_tensor(feature):
        assert len(feature.shape) == 2
        mean = feature.mean(dim=0,keepdim=True)
        var = feature.std(dim=0,keepdim=True)
        return (feature - mean) / (var + 1e-6)


def LDA_loss(H, Y_onehot, nb_each_class_inv_mat, norm_or_not = True): 
    '''
    H is representation matrix of dim n * d
    Y_onehot is a one-hot matrix of dim n * c, c is number of class
    nb_each_class_inv_mat is a diagonal matrix of dim c * c
    this loss encourage node in different class to be as linear seperable as possible
    '''
    result = 0
    weight_sum = 0
    if norm_or_not:
#         do expand_norm won't effect LDA_loss
#         print(norm_or_not)
        H = norm_expand_tensor(H)

#     step1: get shape
    nb_nodes = Y_onehot.shape[0]
    nb_class = Y_onehot.shape[1]
    
#     step2: get mean_mat, each column is a mean vector for a class
    H_T = torch.transpose(H, 0, 1) # transpose of matrix H
    sum_mat = torch.mm(H_T, Y_onehot) # d * c
    mean_mat = torch.mm(sum_mat, nb_each_class_inv_mat) # d * c
    
#     step3: get var_mat, each colums is a variance vector for a class    
    '''
    var(X) = mean(X^2) - mean(X)^2 
    '''
    H2 = H.mul(H) # each item in H2 is the square of corresponding item in H
    H2_T = torch.transpose(H2, 0, 1) # transpose of matrix H2
    sum_mat2 = torch.mm(H2_T, Y_onehot) # d * c
    mean_mat2 = torch.mm(sum_mat2, nb_each_class_inv_mat) # d * c
    var_mat = mean_mat2 - mean_mat.mul(mean_mat) # d * c
    var_mat = torch.relu(var_mat) 

#     step4: for each pair, get weight and score 
    for i in range(nb_class):
        for j in range(i+1, nb_class):
            weight = 1 / nb_each_class_inv_mat[i][i].numpy() + 1 / nb_each_class_inv_mat[j][j].numpy()
            score = LDA_loss_of_a_pair(mean_mat[:,i], mean_mat[:,j], var_mat[:,i], var_mat[:,j])
            weight_sum = weight_sum + weight
            result = result + weight * score

    result = result / weight_sum

    return result


def LDA_loss_of_a_pair(mu1, mu2, sigma1_vec, sigma2_vec): #need to double check
    '''
    mu1, mu2 are two mean vectors of dim d for class 1 and 2
    sigma1, sigma2 are two variance matrix of dim nd*d for class 1 and 2
    '''
    sigma_sum = sigma1_vec + sigma2_vec + 1e-6 # d * 1
    w = (1/sigma_sum).mul(mu1-mu2) # d * 1
    J = w.mul(mu1-mu2).sum()
    #print("mu=", mu1 , mu2, "sigma=", sigma1_vec, sigma2_vec, "w=", w)
    return J

def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

def compare_filters(A, X, Y, idx, features, Y_onehot, nb_each_class_inv_mat_train, norm_or_not):
    tsne = TSNE()
    
    largest_score = 0
    
    types = ['row', 'col', 'sym']
#     types = ['row']
    score = LDA_loss(torch.FloatTensor(features)[idx], Y_onehot[idx], nb_each_class_inv_mat_train, norm_or_not)
    print("the raw separation score is ", score.numpy())
#     print("The raw feature distribution for training set is as follows: ")
#     plot_feature(X[idx], Y[idx], c)
    
    
    for method in types:
        for num in range(2):
            
#       step1: get normalized adjacency matrix, sparse tensor, and plot normalized adjacency matrix's heatmap
            adj_temp = normalization(A, method, num+1)
            adj_temp_tensor = sparse_mx_to_torch_sparse_tensor(adj_temp)
            
    
#       step2: calculate score, print score for train and plot new features
            new_feats = adj_temp * X
            score = LDA_loss(torch.FloatTensor(new_feats)[idx], Y_onehot[idx], nb_each_class_inv_mat_train, norm_or_not)
        
#       step3: print and plot
            print("================================================================")
            print(method, \
                  num+1, ", the separation score is ", score.numpy())
            # print("Then heatmap for filter is: ")
            # plot_heatmap(adj_temp_tensor, Y, c)   
#             print("The new feature distribution for training set is as follows: ")
#             plot_feature(new_feats[idx], Y[idx], c)
            res = tsne.fit_transform(new_feats[idx])
            f = plt.figure()
            plt.scatter(res[:,0], res[:,1],c = Y[idx])
            f.savefig("./figure/{}{}.pdf".format(method,num+1), bbox_inches='tight')
            plt.show()
            
#       step4: store the best 
            if score.numpy()>largest_score:
                norm_method = method
                num_power = num + 1
                largest_score = score.numpy()
    print("The best filter is: ", norm_method, " normalization, propagate ", num_power, " times.")
    return norm_method, num_power